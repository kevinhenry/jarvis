# jarvis

A simple commandline app for searching for sunglasses

# Installation

## Using Pip

```
  $ pip install cver
```

## Manual

```
  $ git clone https://github.com/kevinhenry/jarvis
  $ cd jarvis
  $ python setup.py install
```

# Usage

```
$ jarvis
```

## Search

`search <keyword>`

```
$ jarvis search python
```
## Lookup

`search <name>`

```
$ jarvis
```